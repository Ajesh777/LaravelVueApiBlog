<template>
    <div>
        <nav class="navbar navbar-expand-sm navbar-dark bg-primary mb4">
            <div class="container">
                <a class="navbar-brand" href="#">LsApiArticle</a>
            </div>
        </nav>
    </div>
</template>